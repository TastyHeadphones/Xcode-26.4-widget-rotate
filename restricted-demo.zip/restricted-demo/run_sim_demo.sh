#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_PATH="${ROOT_DIR}/app/DemoApp.app"
BUNDLE_ID="com.widgetrotatekit.demo"

if [[ ! -d "${APP_PATH}" ]]; then
  echo "Missing app bundle: ${APP_PATH}" >&2
  exit 1
fi

DEVICE_ID="$(xcrun simctl list devices available | awk -F '[()]' '/iPhone/ {print $2; exit}')"
if [[ -z "${DEVICE_ID}" ]]; then
  echo "No available iPhone simulator found." >&2
  exit 1
fi

open -a Simulator >/dev/null 2>&1 || true
xcrun simctl boot "${DEVICE_ID}" >/dev/null 2>&1 || true
xcrun simctl bootstatus "${DEVICE_ID}" -b >/dev/null
xcrun simctl install "${DEVICE_ID}" "${APP_PATH}"
xcrun simctl launch "${DEVICE_ID}" "${BUNDLE_ID}"
