# Simulator Run

```bash
./run_sim_demo.sh
```
